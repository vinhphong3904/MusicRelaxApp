package com.example.musicapp.data.model

data class GenreDto(
    val id: Int,
    val name: String,
    val slug: String
)