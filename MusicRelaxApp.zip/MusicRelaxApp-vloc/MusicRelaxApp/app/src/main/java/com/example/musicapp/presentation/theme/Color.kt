package com.example.musicapp.presentation.theme

import androidx.compose.ui.graphics.Color

val SpotifyBlack = Color(0xFF121212)
val SpotifyDark = Color(0xFF181818)
val SpotifyGreen = Color(0xFF1DB954)
val SpotifyWhite = Color(0xFFFFFFFF)
val SpotifyGray = Color(0xFFB3B3B3)
