package com.example.musicapp.data.model.login

data class LoginRequest(
    val username: String,
    val password: String
)