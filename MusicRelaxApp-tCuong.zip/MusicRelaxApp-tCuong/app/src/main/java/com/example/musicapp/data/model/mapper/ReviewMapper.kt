package com.example.musicapp.data.model.mapper

class ReviewMapper {
}