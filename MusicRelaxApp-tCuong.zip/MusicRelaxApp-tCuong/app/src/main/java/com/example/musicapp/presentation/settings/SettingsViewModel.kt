package com.example.musicapp.presentation.settings

class SettingsViewModel {
}