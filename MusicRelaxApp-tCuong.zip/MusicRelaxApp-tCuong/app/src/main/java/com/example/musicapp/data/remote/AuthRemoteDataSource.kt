package com.example.musicapp.data.remote// remote chứa các nguồn dữ liệu từ xa (Retrofit, API, mạng)
// AuthRemoteDataSource.kt chứa Wrapper cho ApiService liên quan đến xác thực người dùng
class AuthRemoteDataSource {}