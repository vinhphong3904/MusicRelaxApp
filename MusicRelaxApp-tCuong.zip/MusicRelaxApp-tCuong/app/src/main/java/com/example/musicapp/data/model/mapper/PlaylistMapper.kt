package com.example.musicapp.data.model.mapper//mapper cho chuyển đổi giữa PlaylistDto, PlaylistEntity, PlaylistModel
// fun PlaylistDto.toEntity(), toModel()