package com.example.musicapp.data.local// local chứa các nguồn dữ liệu cục bộ (Room, SharedPreferences)
// PlaylistLocalDataSource.kt chứa Wrapper cho PlaylistDao
class PlaylistLocalDataSource {}