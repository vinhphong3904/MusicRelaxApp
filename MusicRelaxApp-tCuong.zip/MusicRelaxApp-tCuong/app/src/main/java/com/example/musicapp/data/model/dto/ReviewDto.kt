package com.example.musicapp.data.model.dto

class ReviewDto {
}