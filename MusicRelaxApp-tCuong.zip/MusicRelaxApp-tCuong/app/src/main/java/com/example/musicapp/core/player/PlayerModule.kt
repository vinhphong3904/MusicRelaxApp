package com.example.musicapp.core.player// Hilt: ExoPlayer instance
// PlayerModule.kt cung cấp các dependencies liên quan đến phát nhạc như ExoPlayer, MusicServiceConnection
// và các thành phần khác cần thiết cho việc phát nhạc trong ứng dụng