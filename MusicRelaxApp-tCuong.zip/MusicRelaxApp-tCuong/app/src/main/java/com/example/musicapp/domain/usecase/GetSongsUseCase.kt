package com.example.musicapp.domain.usecase

class GetSongsUseCase {
}