package com.example.musicapp.data.local

class HistoryLocalDataSource {
}