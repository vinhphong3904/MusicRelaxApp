package com.example.musicapp.data.repository

class ArtistRepositoryImpl {
}