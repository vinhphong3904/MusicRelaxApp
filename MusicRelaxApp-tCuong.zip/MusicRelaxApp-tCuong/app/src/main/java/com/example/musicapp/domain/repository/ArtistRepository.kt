package com.example.musicapp.domain.repository

interface ArtistRepository {
}