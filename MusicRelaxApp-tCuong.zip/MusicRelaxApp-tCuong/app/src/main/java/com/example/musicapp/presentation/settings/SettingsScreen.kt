package com.example.musicapp.presentation.settings

class SettingsScreen {
}