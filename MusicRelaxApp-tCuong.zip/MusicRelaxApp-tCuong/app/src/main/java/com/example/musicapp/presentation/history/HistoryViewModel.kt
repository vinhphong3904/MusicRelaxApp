package com.example.musicapp.presentation.history

class HistoryViewModel {
}