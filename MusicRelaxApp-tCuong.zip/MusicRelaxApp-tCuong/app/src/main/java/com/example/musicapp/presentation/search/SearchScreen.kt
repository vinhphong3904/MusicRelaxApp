package com.example.musicapp.presentation.search

class SearchScreen {
}