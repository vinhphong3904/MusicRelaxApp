package com.example.musicapp.domain.model

class Artist {
}